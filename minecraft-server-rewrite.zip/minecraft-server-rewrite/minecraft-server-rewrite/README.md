# minecraft-server

Minecraft server written in Node.js

If you want to get in touch feel free to [send me an email](mailto:danielgulic@gmail.com) or make a GitHub issue on this repo
